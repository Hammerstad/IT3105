/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package classifier.decisiontree;

/**
 *
 * @author Nicklas
 */
public abstract class NodeData {
    @Override
    public abstract String toString();
}
